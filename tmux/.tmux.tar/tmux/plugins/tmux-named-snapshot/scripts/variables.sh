resurrect_save_path_option="@resurrect-save-script-path"
resurrect_restore_path_option="@resurrect-restore-script-path"

resurrect_dir_option="@resurrect-dir"

named_save_option="@named-snapshot-save"
default_save_option="C-m:manual"
named_restore_option="@named-snapshot-restore"
default_restore_option="C-n:manual"
